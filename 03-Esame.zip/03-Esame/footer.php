<footer>
    <div class="container">
      <div class="footer-logo">
        <img src="img/image.png" alt="Logo Gina" height="60">
      </div>
      <p>&copy; 2025 GINA – Tutti i diritti riservati.</p>
    </div>
  </footer>
</body>
</html>
